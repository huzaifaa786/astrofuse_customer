//flutter

class ThemeService {
  // final _key = 'isDarkMode';

  // ThemeMode get theme => _loadThemeFromBox() ? ThemeMode.dark : ThemeMode.light;

  // bool _loadThemeFromBox() => _box.read(_key) ?? false;

  // _saveThemeToBox(bool isDarkMode) => _box.write(_key, isDarkMode);

  // void switchTheme() {
  //   Get.changeThemeMode(_loadThemeFromBox() ? ThemeMode.light : ThemeMode.dark);
  //   _saveThemeToBox(!_loadThemeFromBox());
  // }
}
